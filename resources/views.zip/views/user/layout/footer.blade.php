<!-- Footer -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <a href="https://github.com/msyiham">© 2024 by @github.com/msyiham</a>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->